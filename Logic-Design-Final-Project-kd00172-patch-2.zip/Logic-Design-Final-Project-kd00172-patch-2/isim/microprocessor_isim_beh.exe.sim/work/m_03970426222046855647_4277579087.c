/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/csehome/sagit25/Logic-Design-Final-Project-kd00172-patch-2/Mux_RegDst.v";



static void Always_11_0(char *t0)
{
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    unsigned int t6;
    unsigned int t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(11, ng0);

LAB2:    xsi_set_current_line(12, ng0);
    t1 = (t0 + 1048U);
    t2 = *((char **)t1);
    t1 = (t2 + 4);
    t3 = *((unsigned int *)t1);
    t4 = (~(t3));
    t5 = *((unsigned int *)t2);
    t6 = (t5 & t4);
    t7 = (t6 != 0);
    if (t7 > 0)
        goto LAB3;

LAB4:    xsi_set_current_line(13, ng0);
    t1 = (t0 + 1208U);
    t2 = *((char **)t1);
    t1 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t1, t2, 0, 0, 2, 0LL);

LAB5:    goto LAB5;

LAB3:    xsi_set_current_line(12, ng0);
    t8 = (t0 + 1368U);
    t9 = *((char **)t8);
    t8 = (t0 + 1928);
    xsi_vlogvar_wait_assign_value(t8, t9, 0, 0, 2, 0LL);
    goto LAB5;

LAB1:    return;
}


extern void work_m_03970426222046855647_4277579087_init()
{
	static char *pe[] = {(void *)Always_11_0};
	xsi_register_didat("work_m_03970426222046855647_4277579087", "isim/microprocessor_isim_beh.exe.sim/work/m_03970426222046855647_4277579087.didat");
	xsi_register_executes(pe);
}
