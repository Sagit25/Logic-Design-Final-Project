/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/csehome/sagit25/Logic-Design-Final-Project-kd00172-patch-2/Sign_Extend.v";
static int ng1[] = {6, 0};
static int ng2[] = {7, 0};
static int ng3[] = {2, 0};
static int ng4[] = {1, 0};
static int ng5[] = {0, 0};



static void Cont_10_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    char *t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;

LAB0:    t1 = (t0 + 2680U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(10, ng0);
    t2 = (t0 + 1768);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t0 + 3328);
    t6 = (t5 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    memset(t9, 0, 8);
    t10 = 255U;
    t11 = t10;
    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t10 = (t10 & t13);
    t14 = *((unsigned int *)t12);
    t11 = (t11 & t14);
    t15 = (t9 + 4);
    t16 = *((unsigned int *)t9);
    *((unsigned int *)t9) = (t16 | t10);
    t17 = *((unsigned int *)t15);
    *((unsigned int *)t15) = (t17 | t11);
    xsi_driver_vfirst_trans(t5, 0, 7);
    t18 = (t0 + 3248);
    *((int *)t18) = 1;

LAB1:    return;
}

static void Always_11_1(char *t0)
{
    char t1[8];
    char t5[8];
    char t14[8];
    char t15[8];
    char t16[8];
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    char *t13;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    char *t21;
    char *t22;
    unsigned int t23;
    int t24;
    char *t25;
    unsigned int t26;
    int t27;
    int t28;
    char *t29;
    unsigned int t30;
    int t31;
    int t32;
    unsigned int t33;
    int t34;
    unsigned int t35;
    unsigned int t36;
    int t37;
    int t38;

LAB0:    xsi_set_current_line(11, ng0);

LAB2:    xsi_set_current_line(12, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 1048U);
    t4 = *((char **)t3);
    memset(t5, 0, 8);
    t3 = (t5 + 4);
    t6 = (t4 + 4);
    t7 = *((unsigned int *)t4);
    t8 = (t7 >> 1);
    t9 = (t8 & 1);
    *((unsigned int *)t5) = t9;
    t10 = *((unsigned int *)t6);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t3) = t12;
    xsi_vlog_mul_concat(t1, 6, 1, t2, 1U, t5, 1);
    t13 = (t0 + 1768);
    t17 = (t0 + 1768);
    t18 = (t17 + 72U);
    t19 = *((char **)t18);
    t20 = ((char*)((ng2)));
    t21 = ((char*)((ng3)));
    xsi_vlog_convert_partindices(t14, t15, t16, ((int*)(t19)), 2, t20, 32, 1, t21, 32, 1);
    t22 = (t14 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (!(t23));
    t25 = (t15 + 4);
    t26 = *((unsigned int *)t25);
    t27 = (!(t26));
    t28 = (t24 && t27);
    t29 = (t16 + 4);
    t30 = *((unsigned int *)t29);
    t31 = (!(t30));
    t32 = (t28 && t31);
    if (t32 == 1)
        goto LAB3;

LAB4:    xsi_set_current_line(13, ng0);
    t2 = (t0 + 1048U);
    t3 = *((char **)t2);
    memset(t1, 0, 8);
    t2 = (t1 + 4);
    t4 = (t3 + 4);
    t7 = *((unsigned int *)t3);
    t8 = (t7 >> 0);
    *((unsigned int *)t1) = t8;
    t9 = *((unsigned int *)t4);
    t10 = (t9 >> 0);
    *((unsigned int *)t2) = t10;
    t11 = *((unsigned int *)t1);
    *((unsigned int *)t1) = (t11 & 3U);
    t12 = *((unsigned int *)t2);
    *((unsigned int *)t2) = (t12 & 3U);
    t6 = (t0 + 1768);
    t13 = (t0 + 1768);
    t17 = (t13 + 72U);
    t18 = *((char **)t17);
    t19 = ((char*)((ng4)));
    t20 = ((char*)((ng5)));
    xsi_vlog_convert_partindices(t5, t14, t15, ((int*)(t18)), 2, t19, 32, 1, t20, 32, 1);
    t21 = (t5 + 4);
    t23 = *((unsigned int *)t21);
    t24 = (!(t23));
    t22 = (t14 + 4);
    t26 = *((unsigned int *)t22);
    t27 = (!(t26));
    t28 = (t24 && t27);
    t25 = (t15 + 4);
    t30 = *((unsigned int *)t25);
    t31 = (!(t30));
    t32 = (t28 && t31);
    if (t32 == 1)
        goto LAB5;

LAB6:    goto LAB6;

LAB3:    t33 = *((unsigned int *)t16);
    t34 = (t33 + 0);
    t35 = *((unsigned int *)t14);
    t36 = *((unsigned int *)t15);
    t37 = (t35 - t36);
    t38 = (t37 + 1);
    xsi_vlogvar_wait_assign_value(t13, t1, t34, *((unsigned int *)t15), t38, 0LL);
    goto LAB4;

LAB5:    t33 = *((unsigned int *)t15);
    t34 = (t33 + 0);
    t35 = *((unsigned int *)t5);
    t36 = *((unsigned int *)t14);
    t37 = (t35 - t36);
    t38 = (t37 + 1);
    xsi_vlogvar_wait_assign_value(t6, t1, t34, *((unsigned int *)t14), t38, 0LL);
    goto LAB6;

LAB1:    return;
}


extern void work_m_01740440335531429375_1252407768_init()
{
	static char *pe[] = {(void *)Cont_10_0,(void *)Always_11_1};
	xsi_register_didat("work_m_01740440335531429375_1252407768", "isim/microprocessor_isim_beh.exe.sim/work/m_01740440335531429375_1252407768.didat");
	xsi_register_executes(pe);
}
